class Node: 
      
    def __init__(self, data): 
        self.data = data  
        self.next = None
        self.prev = None
  
class DoublyLinkedList: 
   
    def __init__(self): 
        self.head = None
  
    # Function to merge two linked list 
    def merge(self, first, second): 
           
        if first is None: 
            return second  
      
        if second is None: 
            return first 
  
        # Pick the smaller value 
        if first.data < second.data: 
            first.next = self.merge(first.next, second) 
            first.next.prev = first 
            first.prev = None   
            return first 
        else: 
            second.next = self.merge(first, second.next) 
            second.next.prev = second 
            second.prev = None
            return second 
  
    # Function to do merge sort 
    def mergeSort(self, tempHead): 
        if tempHead is None:  
            return tempHead 
        if tempHead.next is None: 
            return tempHead 
          
        second = self.split(tempHead) 
        tempHead = self.mergeSort(tempHead) 
        second = self.mergeSort(second) 
  
        return self.merge(tempHead, second) 
  
    # Split the doubly linked list (DLL) into two DLLs 
    # of half sizes 
    def split(self, tempHead): 
        fast = slow =  tempHead 
        while(True): 
            if fast.next is None: 
                break
            if fast.next.next is None: 
                break
            fast = fast.next.next 
            slow = slow.next
              
        temp = slow.next
        slow.next = None
        return temp 
          
              
    def push(self, new_data): 
   
        # 1. Allocates node 
        # 2. Put the data in it
        new_node = Node(new_data) 
   
        # 3. Make next of new node as head and 
        # previous as None (already None) 
        new_node.next = self.head 
   
        # 4. change prev of head node to new_node 
        if self.head is not None: 
            self.head.prev = new_node 
   
        # 5. move the head to point to the new node 
        self.head = new_node 
  
  
    def printList(self, node): 
        temp = node 
        print("Forward Traversal using next poitner")
        while(node is not None): 
            print(node.data, end=" ")
            temp = node 
            node = node.next
        print("\nBackward Traversal using prev pointer")
        while(temp): 
            print(temp.data, end=" ") 
            temp = temp.prev 

dll = DoublyLinkedList() 
dll.push(23) 
dll.push(43) 
dll.push(3547) 
dll.push(8) 
dll.push(3457) 
dll.push(1684) 
dll.head = dll.mergeSort(dll.head)    
print("Linked List after sorting")
dll.printList(dll.head) 
