import heapq
heap = []
heapq.heappush(heap, 31)
heapq.heappush(heap, 21)
heapq.heappush(heap, 11)



print("Items in the heap:")
for a in heap:
	print(a)
print("The smallest item in the heap:")
print(heap[0])

print("Pop the smallest item in the heap:")
print(heapq.heappop(heap))
print("remaining elements after popping")
for a in heap:
	print(a)
print("second smallest item after popping first smallest number")
print(heapq.heappop(heap))