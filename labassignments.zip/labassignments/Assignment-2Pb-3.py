class Node: 
  
    # Constructor to initialize the node object 
    def __init__(self, data): 
        self.data = data 
        self.next = None
  
class LinkedList: 
  
    # Function to initialize head 
    def __init__(self): 
        self.head = None
  
    def detectAndRemoveLoop(self): 
        slow_p = fast_p = self.head 
        while(slow_p and fast_p and fast_p.next): 
            slow_p = slow_p.next 
            fast_p = fast_p.next.next
          
            if slow_p == fast_p: 
                self.removeLoop(slow_p) 
                  
        
                return 1 
  
    
        return 0
  

    def removeLoop(self, loop_node): 
          
        # Set a pointer to the beginning of the linked  
        # list and move it one by one
        ptr1 = self.head 
        while(1): 
            # Now start a pointer from loop_node and check 
            # if it ever reaches ptr2 
            ptr2 = loop_node 
            while(ptr2.next != loop_node and ptr2.next != ptr1): 
                ptr2 = ptr2.next
              
            # If ptr2 reached ptr1 then there is a loop. 
            # So break the loop 
            if ptr2.next == ptr1 :  
                break 
              
            ptr1 = ptr1.next
          
        ptr2.next = None
    
    def push(self, new_data): 
        new_node = Node(new_data) 
        new_node.next = self.head 
        self.head = new_node 
  
    # Utility function to prit the linked LinkedList 
    def printList(self): 
        temp = self.head 
        while(temp): 
            print(temp.data, end=" ") 
            temp = temp.next
  
  
llist = LinkedList() 
llist.push(13) 
llist.push(432) 
llist.push(152) 
llist.push(90) 
llist.push(3) 
  
# Creating a loop for testing 
llist.head.next.next.next.next.next = llist.head.next.next
print("\nCREATED A LOOPED LINKED LIST \n if you want to check the loop you can\n")
#IF YOU WANT TO TEST THE LOOP IS WORKING YOU CAN REMOVE THE # BELOW 
#llist.printList() 
llist.detectAndRemoveLoop() 
  
print("Linked List after removing loop")
llist.printList() 
