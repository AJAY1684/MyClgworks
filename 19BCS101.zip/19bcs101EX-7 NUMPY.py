#NUMpy arrray module
import numpy as np
twodmatrix=np.array([[1,2,23],[4,5,6]])
print(twodmatrix)
oneDMatrix= np.array([1054,265,354]) 
print(oneDMatrix)
threeDMatrix = np.array([[[451,223], [53,49]], [[54,68], [721,86]]])
print(threeDMatrix)
fiveId = np.eye(5, dtype=int)
print(fiveId)

#program1
import numpy as np
list1 = [9535.220, 21623.42246, 30340, 6, 533, 4354]
print("List :",list1)
converted_array = np.array(list1)
print("One-dimensional NumPy array: ", converted_array)
#program2
import numpy as np
print("Enter twleve integer values")
a = np.arange(11,20).reshape(3,3)
print(a)

#program 3
r = np.array([343,414,14,45], dtype=np.float64)
print("Size of the array: ", r.size)
print("Length of one array element in bytes: ", r.itemsize)
print("Total bytes consumed by the elements of the array: ",r.nbytes)

#program4
import numpy as np
array1 = np.array([0, 60,34,78])
print("Array1: ",array1)
array2 = [0, 40,34,346,22]
print("Array2: ",array2)
print("Compare each element of array1 and array2")
print(np.in1d(array1, array2))                                 #print the array1 elements are present in boolean as truee or false

#program5
import numpy as np
x = np.array([[0, 10.5, 20.3,45.2,60.4,30.2], [20.5, 30.6,
40.9,50,2,56.9]])
print("first array: ")
print(x)
print("Values bigger than 10 =", x[x>10])
print("Their indices are ", np.nonzero(x > 10))         #it print positon of  items >10

#program6
import numpy as np
x = np.array([[24,5.4,0], [3699, 85, 710]], np.int8)   #the fixed size of np.int numpy numeric arrays may cause overflow , when the size of integers increases
print(type(x))
print(x.shape)
print(x.dtype)

#program 7
import numpy as np
a = np.array([[10, 11, 13], [15, 17, 19],[12,13,16]])
b = np.array([[20, 22, 24], [26, 28, 10],[21,23,25]])
d = np.array([[30, 31, 33], [35, 37, 39],[32,33,36]])
c = np.concatenate((a, b, d), 0)
print(c)
c = np.concatenate((a,b),1)
print(c)

#program8
import numpy as np
x = np.arange(20).reshape((4, 5))
print("Original array:",x)
print("After splitting horizontally:")
print(np.hsplit(x, [1,4]))

#problem 9
import numpy as np
a1=np.array([1,2,3,4])
a2=np.array(['Red','Green','White','Orange'])
a3=np.array([62.20,155,280,40])
result= np.core.records.fromarrays([a1, a2, a3],names='a,b,c')
print(result[0])
print(result[1])
print(result[2])
print(result[3])

#problem 10
import numpy as np
x = np.array([10, 10, 20, 30, 30], float)
print(x)
print("Put 0 and 40 in first and fifth position of the above array")
y = np.array([0, 40, 60], float)
x.put([0, 4], y)
print("Array x, after putting two values:")
print(x)

#program 11
import numpy as np
x= np.arange(12).reshape(3, 4)
print("Original array elements:")
print(x)
print("Above array in small chuncks:")
for a in np.nditer(x, flags=['external_loop'], order='F'):
    print(a)