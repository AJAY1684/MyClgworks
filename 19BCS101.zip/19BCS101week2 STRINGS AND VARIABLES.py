# NUMBERS STRINGS AND VARIABLES                  

#Problem 1
a=2000
house_number= 34                             #created an int object and ts reference to the variable
print(house_number,a)

myhouse_number=house_number                  #Assignment of values
b=a
print(myhouse_number,b)
print(type(house_number),b)

ourhouse = int(house_number)
c=int(b)
print(ourhouse,c)


# Problem 2
''' this type of command is
used for more than one line comment'''
# operation with numbers +,-,*,/,//,%and **
a=3+5
b=5-4
c=(3*3)+6
d=b/a               #performs floating point division
e=b//a              #performs integer type division
f=e
f+=5
g=3**3
print(a,b,c,d,e,f,g)


#problem 3
m=0b10         #base 2
print(m)
n=0o10         #base 8
print(n)      
p=0x4          #base 10
print(p)
numbersize=10**100
numbersize=numbersize*numbersize
print(numbersize)



#prblem 4
a=6.022-15.9997
c=42.0
s=2.143e4
print(a,c,s)


#problem 5
#strings
hello="Good morning"
print(hello)
print('what is your name?')
myName=input()                      #user input
print('It is good to meet you '+myName+'Have a nice day')

#string operations
str1="hello"+"world"
str2="hello"*3
str3="hello"[0]
str4="hello"[-1]
str5="hello"[1:4]
str6=len("hello")
print(str1,str2,str3,str4,str5,str6)


