#EXERCISE -1
#SORT THE ELEMENTS AND GET THE LIST

my_list = [34,45,56,43,53,34,54,45,65,3,653,5,43,34,65]
def first_second(given_list):
    a=given_list                  #copying list into a
    a.sort(reverse=True)
    print(a)
    first = a[0]
    second = None
    for element in my_list:
        if element != first:
            second = element
            return first,second

#fun called
f,s = first_second(my_list)
print(f,s)


#EXERCISE-2
fm = [[1,2,3],[7,8,9],[4,5,6]]
sm = [[1,1,1],[1,0,1],[1,1,0]]
tm= [[2,0],[0,2]]

def sum_of_Diagnl(matrixitems):        #Defining function
    sum = 0
    for i in range(len(matrixitems)):
        sum += matrixitems[i][i]
    return sum 

print("FIRST MATRIX:",sum_of_Diagnl(fm))
print("SECOND MATRIX:",sum_of_Diagnl(sm))
print("Third Matrix:",sum_of_Diagnl(tm))

#EXERCCISE-3
           #list operation

list_items = ["AA","KK",55,"aa",2638.8,"Tt","Kk",45,"An","kak","3456.0"]

stritems=[]
numitems = []
for item in list_items:
    if isinstance(item,str):
        stritems.append(item)
    elif isinstance(item,int) or isinstance(item,float):
        numitems.append(item)
print(stritems)
print(numitems)

#str in ASCndng order
str_asc=sorted(stritems,key=str.lower)
print("srting order a-z ::",str_asc)

#str in dscnding order
str_desc = sorted(stritems,key=str.lower,reverse=True)
print("string orderZ-A ::",str_desc)

#sorting numbers list in asending order
num_asc = sorted(numitems)
print("NUM IN ASC :",num_asc)

#descending numbers
num_desc = sorted(numitems,reverse=True)
print("NUM DESCENDING ORDER:",num_desc)


#list membership test
my_list=['a','k','h','i','l']
print('a' in my_list)
print('b' in my_list)

for fruit in ['APPLE','banana','MANGO']:
    print("i like",fruit)


mytuple = (1,2,3,"hello",45678.02,[1,3,4,5],(3,3,43,64))
print(mytuple)
print(mytuple[0])
print(mytuple[5])
print(mytuple[6][3])
print(mytuple[6].count(3))
print(mytuple[6].index(3))
del mytuple
mytuple= ("tuple is successfully deleted")
print(mytuple)