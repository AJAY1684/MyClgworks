#BIG O NOTATION

#PROBLEM 1

import array as myarray
import time
import matplotlib.pyplot as plt 
import sys                                             # To know about the working and the allocation  process of system


print("Enter loop value :",end="")
input_value=input()

temp=myarray.array('i',[2,3])
array_size = sys.getsizeof(temp)
block_size=sys.getallocatedblocks()
total_time_array=[]
arr_len=[]
print("initial Allocsted list size:",sys.getsizeof(arr_len))
print("Array size and block size before execution:",array_size,block_size)
start_time=time.time()                          # taking starting execution time

#increasing array length every time 
for run_loop in range(0,int(input_value),1):
    arr_len.append(len(temp))
    for k in range (0,10000):
        t=0
    for j in range(1,5):
        temp.append(run_loop+j)
    end_time=time.time()
    total_time=round((end_time-start_time),7)
    total_time_array.append(total_time) 
    run_loop += run_loop

# Plotting the graph of execution time versus input size
array_size=sys.getsizeof(temp)
print("array size and block size after execution :",array_size,block_size)
s=total_time_array
p=arr_len
print("printing total time array  ,  array length")
print(s,p)
plt.plot(p,s)
plt.show()

