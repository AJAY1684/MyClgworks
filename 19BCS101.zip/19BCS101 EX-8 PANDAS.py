import pandas as pd
import os

#program1
data = {
'apples': [300, 240, 100, 140],
'oranges': [125, 380, 750, 460],
'Grapes': [580,350,900,630],
'Banana' : [750,800,300,540]
}
sales = pd.DataFrame(data)
print(sales)
sales = pd.DataFrame(data, index=['KL', 'KR', 'TN', 'WB'])
print(sales)
print(sales.loc['TN'])

# Program2 :
def Convert(toConvert):
    finalDict = { toConvert[i]: toConvert[i + 1] for i in range(0,len(toConvert), 3 )}
    return finalDict
# list creation code
myList1 = ['apples', 3000,240,100,146]
print(myList1)