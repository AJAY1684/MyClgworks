#Exercise 9
#Stacks nd Queues
#Exercise 9
#Stacks nd Queues
class Stack :
     def __init__(self):
         self._items = list()
     def isEmpty(self):
         return len(self) == 0
     def __len__ (self) :
         return len(self._items)
     def peek (self):
         assert not self.isEmpty()
         return self._items[-1]
     def pop (self):
         assert not self.isEmpty() 
         return self._items.pop()
     def push (self,item):
         self._items.append(item)

#Main Program
myStack = Stack()
userprompt = ''
value = input(userprompt)
while int(value) >= 0:
     myStack.push(value)
     value = int(input(userprompt))
while not myStack.isEmpty() :
     value = myStack.pop()
     print(value)

import queue
import collections
Lq = queue.LifoQueue(maxsize = 6)
Lq.put(7)
Lq.put(1)
Lq.put(3)
print(Lq.qsize())
print("Full: ", Lq.full(), "Size: ", Lq.qsize())
print("Empty: ",Lq.empty())

#Import collections and Deque package
#Creating a deque
DeQ = collections.deque(["Fri","Sat","Sun"])
print(DeQ)

#Appending to right
print("Adding to right: ")
DeQ.append("Mon")
print(DeQ)

#Appending to left
print("Adding to left: ")
DeQ.appendleft("Thurs")
print(DeQ)

#Remove from left
print("Removing from left: ")
DeQ.popleft()
print(DeQ)

#Reverse dequeue
print("Reversing the deque: ")
DeQ.reverse()
print(DeQ)

# Initializing a queue  
queue = []    
# Adding elements to the queue  
queue.append('m')  
queue.append('n')  
queue.append('o')  
print("Initial queue")
print(queue)  
# Removing elements from the queue
print("\nElements dequeued from queue")  
print(queue.pop(0)) 
print(queue.pop(0)) 
print(queue.pop(0))  
print("\nQueue after removing elements")
print(queue)   



