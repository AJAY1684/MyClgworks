#create a variable and print the value
#problem1
akhilsavings = 550
print(akhilsavings)
#it will print the value of my savings



#problem 2
# create a variable akhilsavings
akhilsavings=2500
#create a variable time
time=6.0
#calculate result
result=akhilsavings*time*2
#print the result
print(result)



#problem 3

#create a variable others with the value like a string akhilsavings
others="akhil savings"
#create a varable profitable
profitable = True
loss = False
print(others)
print(profitable)



# problem 4

akhil_savings=200
rate=2
others="compound interest "
#assign product of balance and my savings to first_year_balance
first_year_balance = akhil_savings*rate
#print the type of first year balance
print(type(first_year_balance)) 
# Assign the sum of others and others to double others 
double_value_others = others*rate
 #for printing two strings we can multiply or add string others+others
print(double_value_others) 
# converting int rate into a string using str()
print(double_value_others + str(rate))
#adding boolean true
double_same_true_boolean = profitable + profitable
print(double_same_true_boolean)
#adding boolean false
print(loss+loss)
print(loss-profitable)
print(str(profitable),str(loss))



# problem 5

#defining savings and result
akhil_savings=2000
balance=akhil_savings*2*1.5
print("My account had $" + str(akhil_savings) + "to begin with" + "Now i have $"+str(balance) + ".Awesome!")
#definition of pi_string
pi_string = "3.1415926"
#converting pi_string to pi_float
pi_float = str(pi_string)
print(pi_float)















