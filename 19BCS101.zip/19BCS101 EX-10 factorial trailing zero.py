import math
def is_positive_integer(x):
     try:
         x = float(x)
     except ValueError:
         return False
     else:
         if x.is_integer() and x > 0:
             return True
         else:
             return False
def trailing_zeros(num):
     if is_positive_integer(num):

         num = int(num)
         k = math.floor(math.log(num, 5))
         zeros = 0
         for i in range(1, k + 1):
             zeros = zeros + math.floor(num/math.pow(5, i))
         return zeros
     else:
         print("Factorial of a non-positive non-integer is undefined")


if __name__ == "__main__":
     fact_num = input("Enter the number for which we are finding factorial's trailing zeros: ")
     num_zeros = trailing_zeros(fact_num)
     print("Trailing zeros in the Number: {0}".format(num_zeros))


import matplotlib.pyplot as plt
def plot_forecast():
    time_of_day = ['4 AM', '7 AM', '10 AM', '1 PM', '4 PM', '7PM', '10PM']
    forecast_temp = [71, 70, 74, 80, 82, 81, 76]
    time_interval = range(1, len(time_of_day) + 1)
    plt.plot(time_interval, forecast_temp, 'o-')
    plt.xticks(time_interval, time_of_day)
    plt.show()
if __name__ == '__main__':
    plot_forecast()     

import matplotlib.pyplot as plt
def draw_graph(x, y):
    plt.plot(x, y)
    plt.show()
if __name__ == '__main__': 

    x_values = range(-100, 100, 20)
    y_values = []
    for x in x_values:

        y_values.append(x**2 + 2*x + 1)
    draw_graph(x_values, y_values)

