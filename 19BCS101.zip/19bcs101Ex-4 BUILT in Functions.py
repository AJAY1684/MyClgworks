#IMPORT OPERATOR MODULE

import operator

a=9
b=4

print("the addition of numbers is :",end="" );            #adding
print(operator.add(a,b))
print("the difference of numbers is :",end="" );               #subtraction
print(operator.sub(a,b))
print("the product of numbers is :",end="" );          #multiplication
print(operator.mul(a,b))
   
a=10
b=4

print("the true division of numbers is:",end="");
print(operator.truediv(a,b))

print("the floor division of numbers is:",end="");
print(operator.floordiv(a,b))

print("The exponentiation of numbers is :",end="");
print(operator.pow(a,b))

print("The modulus of numbers is : ",end="");
print(operator.mod(a,b))

a = 34
b = 34
if(operator.lt(a,b)):
    print ("34 is less than 34")
else : 
    print ("34 is not less than 34")

if(operator.le(a,b)):
    print("34 is less than or equal to 34")
else:
     print("34 is not less than or equal to 34")

if (operator.eq(a,b)):
    print ("34 is equal to 34")
else : 
    print ("34 is not equal to 34")

a=438
b=457

if(operator.ge(a,b)):
    print("438 is greatert than or equal to 457")
else:
     print("438 is not greatert than or equal to 457")

if(operator.gt(a,b)):
    print("438 is greatert than to 457")
else:
    print("438 is not greatert than to 457")

if(operator.ne(a,b)):
    print("438 is not equal to 457")
else:
    print("438 is not equal to 457")


















  