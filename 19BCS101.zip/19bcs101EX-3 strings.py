#Python string slicing 

#Problem:1

s='kulasekhar'
print(s[:])
print(s[::])
first_five_char = s[:5]
print(first_five_char)
third_to_fifth_char = s[2:5]
print(third_to_fifth_char)


#Problem 2 slicing of strings using functionn slice

take_string = 'harshavardhan'
slice_string1 = slice(-1,6,-1)
slice_string2 = slice(1,6,-1)
slice_string3 = slice(1,6,1)
slice_string4 = slice(-1,-5,1)
print("problem 2")
print(take_string[slice_string1])
print(take_string[slice_string2])
print(take_string[slice_string3])
print(take_string[slice_string4])


#Problem 3 reverse string using slicing

s = "business man"
reverseString = s[::-1]
reverseString2 = s[:-1]
print(reverseString)
print(reverseString2)
s1=s[2:8:2]
print(s1)
s1=s[8:1:-1]
print(s1)

s1 = s[-4:-2]
s1 = s[8:1:-2]
print(s1)

s1 = s[-4:-2]
print(s1)

s = "ramana"
s1 = s[100:]
print(s1)



#Problem 4        get sub list sub tuple
py_string = 'Ankitha'
slice_object = slice(4)
print("problem 4")
print(py_string[slice_object])

slice_object = slice(1,6,2)
print(py_string[slice_object])


#problem 5
py_list = ['A','N','K','I','T','H','A']
py_tuple = ('A','N','K','I','T','H','A')
print('problem 5')
slice_object = slice(3)
print(py_list[slice_object])

slice_object = slice(1,5,2)
print(py_list[slice_object])

slice_object = slice(-1, -4, -1)
print(py_list[slice_object])

slice_object = slice(-1, -5, -2)
print(py_tuple[slice_object])












